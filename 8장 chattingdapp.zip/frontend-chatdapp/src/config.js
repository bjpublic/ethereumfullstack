const Vote = require('./contracts/Vote')

export default {
	VOTE_CA: '0xa07ceac27f0d463fdeacec62647fbc7749901a9f',
	VOTE_ABI: Vote.abi,

	GAS_AMOUNT: 500000
}
