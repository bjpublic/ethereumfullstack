<template>
  <div>
    <h2>Upload Page</h2>
    <MyUpload />    
  </div>	
</template>
<script>
import MyUpload from '@/components/MyUpload.vue'

export default {
  components: {
    MyUpload    
  } 
}
</script>
