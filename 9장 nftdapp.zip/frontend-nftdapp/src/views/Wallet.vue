<template>
  <div>
    <h2>Wallet Page</h2>  
    <MyWallet />
  </div>
</template>

<script>
  import MyWallet from '@/components/MyWallet.vue'

  export default {     
    components: { 
      MyWallet
    }
  }
</script>
