<template>
  <div>
    <h2>Main Page</h2>  
    <Marketplace />  
  </div>
</template>
<script>
  import Marketplace from '@/components/Marketplace.vue'

  export default {
    components: { 
      Marketplace
    }
  } 
</script>
